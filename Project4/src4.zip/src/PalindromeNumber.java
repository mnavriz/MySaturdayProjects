import java.util.Arrays;

public class PalindromeNumber {

      /*
        Given a method name is returnNum
        Parameter is one int
        Return type is int

        Reverse int (that is, re-form an int by reversing the order of the digits of the parameter int)
        Return the reversed int

        Example:
        int  = 1234

        return should be 4321
     */

    public int returnNum(int number) {

       String str = Integer.toString(number);
       String str2 =  "";

        for (int i = str.length()-1; i>=0 ; i--) {
            str2 += str.charAt(i);
        }
       int reversed = Integer.parseInt(str2);
        return reversed;
    }

    /*
        Given palindromeNum method
        Parameter is one int (num1)
        Return type is one int

        Palindrome means a word or number reads the same backward as forward like "mom" , "refer" , "131" , "1221"

       Add num1 and reverse of num1, find the result.
       Check if the result is a palindrome or not.
       If the result is not a palindrome number, find the reverse of the result.
       And add the result and reverse of the result, find the new total.
       Check if the new total is a palindrome or not.
       Do the same steps until you reach a palindrome number in your result.
       After you reached the palindrome number, find the count that how many times you did the same operation to reach a palindrome number.
       Return the count

        Example:
            num1 = 349  --> 349  + 943 = 1292     Note : since 1292 is not palindrome do the same step for this  // first operation
                            1292 + 2921 = 4213   Note : 4213 is not palindrome  do the same step for this // second operation
                            4213 + 3124 = 7337   Note : 7337 is palindrome      // third operation  you reached the palindrome so count is 3

        return should be 3
        HINT: You better use while loop for this question

     */

    public int palindromeNum(int num1){
        int count = 0;
        int result = num1 + returnNum(num1);
        count++;

        while(returnNum(result)!=result){
            count++;
            result += returnNum(result); // result = result + returnNum(result);
        }

        return count;
    }


}
